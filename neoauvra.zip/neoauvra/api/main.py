from flask import Flask, request, jsonify
import pymongo
import hashlib
import uuid

app = Flask(__name__)
app.config["DEBUG"] = False

client = pymongo.MongoClient('mongodb://127.0.0.1:27017/')
mydb = client['users']
mycol = mydb['user']


@app.route('/user', methods=['GET'])
def get():
    try:
        username = request.args.get("username")
        password = request.args.get("password")
        result = hashlib.sha256(password.encode())
        myquery = {
            'user_name': username,
            'user_pass': result.hexdigest()
        }
        count = mycol.count_documents(myquery)
        if count == 1:
            token = uuid.uuid1()
            mycol.update_one(myquery, {"$set": {"token": str(token)}})
            return "{\"status\":\"success\", \"token\": \"" + str(token) + "\"}"
        else:
            return "{\"status\":\"fail\"}"
    except:
        return "{\"status\":\"fail\"}"


@app.route('/userInfo', methods=['GET'])
def userInfo():
    try:
        token = request.args.get("token")
        myquery = {
            'token': str(token)
        }
        count = mycol.count_documents(myquery)
        if count == 1:
            return "{\"status\":\"success\", \"username\": \"" + mycol.find(myquery)[0].get("user_name") + "\"}"
        else:
            return "{\"status\":\"fail\"}"
    except:
        return "{\"status\":\"fail\"}"


@app.route('/user', methods=['POST'])
def post():
    username = request.args.get("username")
    password = request.args.get("password")
    return username + " " + password


@app.route('/createuser', methods=['POST'])
def create_user():
    try:
        username = request.args.get("username")
        password = request.args.get("password")

        myquery = {"user_name": username}
        count = mycol.count_documents(myquery)
        if count == 0:
            result = hashlib.sha256(password.encode())
            json = {
                "user_name": username,
                "user_pass": result.hexdigest(),
                "token": ""
            }
            mycol.insert_one(json)
            return "{\"status\":\"success\"}"
        else:
            return "{\"status\":\"fail\"}"
    except:
        return "{\"status\":\"fail\"}"


app.run()
