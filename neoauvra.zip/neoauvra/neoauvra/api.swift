//
//  api.swift
//  neoauvra
//
//  Created by Bartu Kaynar on 13.08.2022.
//


import UIKit

// GET POST PUT DELETE





