//
//  neoauvraApp.swift
//  neoauvra
//
//  Created by Bartu Kaynar on 13.08.2022.
//

import SwiftUI

@main
struct neoauvraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
