//
//  ContentView.swift
//  neoauvra
//
//  Created by Bartu Kaynar on 13.08.2022.
//

import SwiftUI

struct UserExpenses: Decodable {
    let status:String
    let max:[Double]
    let min:[Double]
    let average:[Double]
}

struct ContentView: View {
    @State var isMain = false
    @State var isRegister = false
    @State var token = ""
    
    var preferences = UserDefaults.standard
    
    var body: some View {
        ZStack{
            if isMain{
                MainView(isMain: $isMain, isRegister: $isRegister, token: $token)
                    .onAppear(){
                        if preferences.object(forKey: "token") != nil {
                            self.token = preferences.object(forKey: "token") as! String
                            NotificationCenter.default.post(name: Notification.Name("CHEK_DATA"), object: nil)
                        }
                    }
            } else if isRegister {
                RegisterView(isMain: $isMain, isRegister: $isRegister)
            } else {
                LoginView(isMain: $isMain, isRegister: $isRegister)
            }
        }
        .onAppear(){
            //preferences.removeObject(forKey: "token")
            if preferences.object(forKey: "token") != nil {
                self.isMain = true
                self.isRegister = false
            }
        }
    }
}

struct LoginView:View{
    @Binding var isMain:Bool
    @Binding var isRegister:Bool
    
    @State var nameText = ""
    @State var passwordText = ""
    @State var loginAlert = false
    
    var preferences = UserDefaults.standard
    
    var body: some View{
        ZStack{
            GeometryReader { geo in
                Image("bg")
                    .resizable()
                    .aspectRatio(contentMode: ContentMode.fill)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()
                VStack{
                    Spacer()
                    VStack{
                        Image("logo")
                            .padding(.top)
                        Text("Login")
                            .foregroundColor(Color(red: 18/255, green: 10/255, blue: 143/255))
                        
                        TextField(text: $nameText, label: {
                            Text(nameText != "" ? "" : "Name..")
                        })
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                        
                        SecureField(text: $passwordText, label: {
                            Text(passwordText != "" ? "" : "Password..")
                        })
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                        
                        CustomDivider(color: Color.white, height: 1.2)
                            .padding(.horizontal,30)
                            .padding(.vertical)
                        
                        HStack{
                            Button(action: {
                                self.isMain = false
                                self.isRegister = true
                            }, label: {
                                Text("Sing Up")
                                    .padding()
                            })
                            Spacer()
                            Button(action: {
                                if nameText == "" || passwordText == "" {return}
                                login(name: nameText, password: passwordText)
                            }, label: {
                                Text("Login")
                                    .padding()
                            })
                        }
                        .padding(.bottom)
                    }
                    .frame(width: geo.size.width)
                    .background(Color.cardViewBg)
                    .cornerRadius(20, corners: [.topLeft, .topRight])
                }
            }
            .frame(width: UIScreen.screenWidth, height: .infinity)
            .ignoresSafeArea()
            .alert("Username or password incorrect!", isPresented: $loginAlert) {
                Button("OK", role: .cancel) { }
            }
        }
    }
    
    func login(name:String, password:String) {
        let urla = "http://127.0.0.1:5000/user?username=\(name)&password=\(password)"
        let cString = urla.cString(using: String.Encoding.utf8)
        let encodedStr = NSString(bytes: ((cString))!, length: ((cString?.count))!, encoding: String.Encoding.utf8.rawValue)!
        let controlCharStr = NSString(format: "%@", encodedStr.trimmingCharacters(in: CharacterSet.controlCharacters))
        let urlStr = controlCharStr.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlFragmentAllowed)
        guard let url = URL(string: urlStr ?? "") else { return }
        var request = URLRequest(url: url,timeoutInterval: Double.infinity)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else { return }
            do {
                let jsonObj = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                guard let status = jsonObj!["status"] as? String else { return }
                if status == "success"{
                    guard let token = jsonObj!["token"] as? String else { return }
                    preferences.set(token, forKey: "token")
                    self.isMain = true
                    self.isRegister = false
                    NotificationCenter.default.post(name: Notification.Name("CHEK_DATA"), object: nil)
                } else {
                    self.loginAlert.toggle()
                }
            } catch let error as NSError {
                self.loginAlert.toggle()
            }
        }
        task.resume()
    }
}

struct RegisterView:View{
    @Binding var isMain:Bool
    @Binding var isRegister:Bool
    
    @State var nameText = ""
    @State var passwordText = ""
    @State var passwordConrimText = ""
    
    @State var registerPassError = false
    @State var registerUsernameError = false
    
    
    var body: some View{
        ZStack{
            GeometryReader { geo in
                Image("bg")
                    .resizable()
                    .aspectRatio(contentMode: ContentMode.fill)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()
                VStack{
                    Spacer()
                    VStack{
                        Image("logo")
                            .padding(.top)
                        Text("Sing Up")
                            .foregroundColor(Color(red: 18/255, green: 10/255, blue: 143/255))
                        
                        TextField(text: $nameText, label: {
                            Text(nameText != "" ? "" : "Name..")
                        })
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                        
                        SecureField(text: $passwordText, label: {
                            Text(passwordText != "" ? "" : "Password..")
                        })
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                        
                        SecureField(text: $passwordConrimText, label: {
                            Text(passwordConrimText != "" ? "" : "Confirm Password..")
                        })
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                        
                        CustomDivider(color: Color.white, height: 1.2)
                            .padding(.horizontal,30)
                            .padding(.vertical)
                        
                        HStack {
                            Button(action: {
                                self.isMain = false
                                self.isRegister = false
                            }, label: {
                                Text("Login")
                                    .padding()
                            })
                            Spacer()
                            Button(action: {
                                if passwordText == passwordConrimText {
                                    createUser(name: nameText, password: passwordText)
                                } else {
                                    self.registerPassError.toggle()
                                }
                            }, label: {
                                Text("Sing Up")
                                    .padding()
                            })
                        }
                        .padding(.bottom)
                    }
                    .frame(width: geo.size.width)
                    .background(Color.cardViewBg)
                    .cornerRadius(20, corners: [.topLeft, .topRight])
                }
            }
            .frame(width: UIScreen.screenWidth, height: .infinity)
            .ignoresSafeArea()
        }
        .alert("Passwords are not matching!", isPresented: $registerPassError) {
            Button("OK", role: .cancel) {}
        }
        .alert("Username has already taken! Please choose another username.", isPresented: $registerUsernameError) {
            Button("OK", role: .cancel) {}
        }
    }
    
    func createUser(name:String, password:String) {
        let urla = "http://127.0.0.1:5000/createuser?username=\(name)&password=\(password)"
        let cString = urla.cString(using: String.Encoding.utf8)
        let encodedStr = NSString(bytes: ((cString))!, length: ((cString?.count))!, encoding: String.Encoding.utf8.rawValue)!
        let controlCharStr = NSString(format: "%@", encodedStr.trimmingCharacters(in: CharacterSet.controlCharacters))
        let urlStr = controlCharStr.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlFragmentAllowed)
        guard let url = URL(string: urlStr ?? "") else { return }
        var request = URLRequest(url: url,timeoutInterval: Double.infinity)
        request.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else { return }
            do {
                let jsonObj = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                guard let status = jsonObj!["status"] as? String else { return }
                if status == "success"{
                    self.isMain = false
                    self.isRegister = false
                } else {
                    self.registerUsernameError.toggle()
                }
            } catch {
                self.registerUsernameError.toggle()
            }
        }
        task.resume()
    }
}

struct MainView:View{
    @Binding var isMain:Bool
    @Binding var isRegister:Bool
    @Binding var token:String
    
    @State var value:CGFloat = 0.3
    
    @State var max:[Double] = []
    @State var min:[Double] = []
    @State var average:[Double] = []
    @State var percent:[Double] = []
    
    @State var sector = 0
    @State var expand = false
    
    var body: some View{
        ZStack{
            VStack{
                HStack{
                    Spacer()
                    Button(action: {
                        UserDefaults.standard.removeObject(forKey: "token")
                        self.isMain = false
                        self.isRegister = false
                    }, label: {
                        HStack{
                            Text("Logout")
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                        }
                        .padding()
                    })
                }
                HStack{
                    HStack{
                        Circle()
                            .foregroundColor(Color.cyan)
                            .frame(width: 10, height: 10)
                        Text("Minimum")
                    }
                    HStack{
                        Circle()
                            .foregroundColor(Color.orange)
                            .frame(width: 10, height: 10)
                        Text("Average")
                    }
                    HStack{
                        Circle()
                            .foregroundColor(Color.green)
                            .frame(width: 10, height: 10)
                        Text("Maximum")
                    }
                }
                .padding(.vertical)
                ZStack{
                    if self.max.count > 0 {
                        LineView(dataPoints: self.max, color: .green)
                            .frame(width: 300, height: 200)
                    }
                    if self.min.count > 0 {
                        LineView(dataPoints: self.min, color: .blue)
                            .frame(width: 300, height: 200)
                    }
                    if self.average.count > 0 {
                        LineView(dataPoints: self.average, color: .orange)
                            .frame(width: 300, height: 200)
                    }
                }
                Spacer()
                VStack{
                    Spacer()
                    VStack{
                        HStack{
                            Text("Sector")
                                .fontWeight(.bold)
                            Image(systemName: expand ? "chevron.up" : "chevron.down")
                                .resizable()
                                .frame(width: 13, height: 6)
                        }
                        .onTapGesture {
                            self.expand.toggle()
                        }
                        if expand {
                            Group{
                                Button(action: {
                                    value = self.percent[0]
                                    self.expand.toggle()
                                }){
                                    Text("Healtcare")
                                        .padding()
                                }
                                Button(action: {
                                    value = self.percent[1]
                                    self.expand.toggle()
                                }){
                                    Text("Food")
                                        .padding()
                                }
                                Button(action: {
                                    value = self.percent[2]
                                    self.expand.toggle()
                                }){
                                    Text("Transportation")
                                        .padding()
                                }
                                Button(action: {
                                    value = self.percent[3]
                                    self.expand.toggle()
                                }){
                                    Text("Housing")
                                        .padding()
                                }
                                Button(action: {
                                    value = self.percent[4]
                                    self.expand.toggle()
                                }){
                                    Text("Education")
                                        .padding()
                                }
                            }
                        }
                    }
                    .padding()
                    .cornerRadius(15)
                    .animation(.spring())
                }
                CustomProgressView(value: $value)
                    .frame(width:300,height: 300)
                    .padding()
            }
        }
        .onAppear(){
            let globalQueue = DispatchQueue.global()
            NotificationCenter.default.addObserver(forName: NSNotification.Name("CHEK_DATA"), object: nil, queue: .main) { (_) in
                globalQueue.async {
                    guard let url = URL(string: "http://127.0.0.1:5000/userInfo?token=\(token)") else {return}
                    var request = URLRequest(url: url,timeoutInterval: Double.infinity)
                    request.httpMethod = "GET"
                    
                    let task = URLSession.shared.dataTask(with: request) { data, response, error in
                        guard let data = data else { return }
                        do {
                            let jsonObj = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                            guard let status = jsonObj!["status"] as? String else { return }
                            if status == "success"{
                                guard let username = jsonObj!["username"] as? String else { return }
                                getDatas(username: username)
                                getPercent(username: username)
                            }
                        } catch {
                            
                        }
                    }
                    task.resume()
                }
            }
        }
    }
    
    func getDatas(username: String){
        let urla = "http://127.0.0.1:5001/getuserexpenses?username=\(username)"
        let cString = urla.cString(using: String.Encoding.utf8)
        let encodedStr = NSString(bytes: ((cString))!, length: ((cString?.count))!, encoding: String.Encoding.utf8.rawValue)!
        let controlCharStr = NSString(format: "%@", encodedStr.trimmingCharacters(in: CharacterSet.controlCharacters))
        let urlStr = controlCharStr.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlFragmentAllowed)
        guard let url = URL(string: urlStr ?? "") else { return }
        var request = URLRequest(url: url,timeoutInterval: Double.infinity)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {return}
            do {
                let jsonData = try JSONDecoder().decode(UserExpenses.self, from: data)
                if jsonData.status == "success" {
                    self.average = jsonData.average
                    self.max = jsonData.max
                    self.min = jsonData.min
                }
            }
            catch let error as NSError {
                print("\(error)")
            }
        }
        task.resume()
    }
    
    func getPercent(username: String){
        let urla = "http://127.0.0.1:5001/getpercexpenses?customer_name=\(username)"
        let cString = urla.cString(using: String.Encoding.utf8)
        let encodedStr = NSString(bytes: ((cString))!, length: ((cString?.count))!, encoding: String.Encoding.utf8.rawValue)!
        let controlCharStr = NSString(format: "%@", encodedStr.trimmingCharacters(in: CharacterSet.controlCharacters))
        let urlStr = controlCharStr.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlFragmentAllowed)
        guard let url = URL(string: urlStr ?? "") else { return }
        var request = URLRequest(url: url,timeoutInterval: Double.infinity)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {return}
            do {
                let jsonObj = try JSONSerialization.jsonObject(with: data, options: []) as? [Double] ?? []
                self.percent = jsonObj
            }
            catch let error as NSError {
                print("\(error)")
            }
        }
        task.resume()
    }
}

struct CustomProgressView:View{
    @Binding var value:CGFloat
    
    var body: some View{
        ZStack{
            GeometryReader{ geo in
                Circle()
                    .inset(by: 6)
                    .stroke(Color.blue, lineWidth: 5)
                    .foregroundColor(Color(red: 18/255, green: 10/255, blue: 143/255))
                    .frame(width: geo.size.width, height: geo.size.height)
                
                Circle()
                    .inset(by: 34)
                    .trim(from: 0, to: CGFloat(value)/100)
                    .stroke(Color.orange, lineWidth: 30)
                    .rotationEffect(.degrees(-90))
                    .frame(width: geo.size.width, height: geo.size.height)
                
                Circle()
                    .inset(by: 60)
                    .foregroundColor(Color(red: 18/255, green: 10/255, blue: 143/255))
                    .overlay(
                        Text("\(Float(value).clean)%")
                            .bold()
                            .font(.system(size: 30))
                            .foregroundColor(Color.white)
                        
                    )
                    .frame(width: geo.size.width, height: geo.size.height)
            }
        }
    }
}

struct CustomDivider: View {
    let color: Color
    let height: CGFloat
    
    init(color: Color = .gray.opacity(0.5),
         height: CGFloat = 0.5) {
        self.color = color
        self.height = height
    }
    
    var body: some View {
        Rectangle()
            .fill(color)
            .frame(height: height)
            .edgesIgnoringSafeArea(.horizontal)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

extension Color {
    static let cardViewBg = Color(red: 234/255, green: 229/255, blue: 226/255)
}

extension UIScreen{
    static let screenWidth = UIScreen.main.bounds.size.width
    static let screenHeight = UIScreen.main.bounds.size.height
    static let screenSize = UIScreen.main.bounds.size
}

extension Float {
    var clean: String {
        return self.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", self) : String(self)
    }
}

struct CornerRadiusStyle: ViewModifier {
    var radius: CGFloat
    var corners: UIRectCorner
    
    struct CornerRadiusShape: Shape {
        
        var radius = CGFloat.infinity
        var corners = UIRectCorner.allCorners
        
        func path(in rect: CGRect) -> Path {
            let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
            return Path(path.cgPath)
        }
    }
    
    func body(content: Content) -> some View {
        content
            .clipShape(CornerRadiusShape(radius: radius, corners: corners))
    }
}

struct Response: Codable{
    let body: String
    let user_name: String
    let user_pass: String
}

extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        ModifiedContent(content: self, modifier: CornerRadiusStyle(radius: radius, corners: corners))
    }
}

struct LineView: View {
    var dataPoints: [Double]
    var color:Color
    
    var highestPoint: Double {
        let max = dataPoints.max() ?? 1.0
        if max == 0 { return 1.0 }
        return max
    }
    
    var body: some View {
        GeometryReader { geometry in
            let height = geometry.size.height
            let width = geometry.size.width
            
            Path { path in
                path.move(to: CGPoint(x: 0, y: height * self.ratio(for: 0)))
                
                for index in 1..<dataPoints.count {
                    path.addLine(to: CGPoint(
                        x: CGFloat(index) * width / CGFloat(dataPoints.count - 1),
                        y: height * self.ratio(for: index)))
                }
            }
            .stroke(color, style: StrokeStyle(lineWidth: 2, lineJoin: .round))
        }
        .padding(.vertical)
    }
    
    private func ratio(for index: Int) -> Double {
        1 - (dataPoints[index] / highestPoint)
    }
}
