import csv
import pymongo
from flask import Flask, request, jsonify
from bson.json_util import dumps, loads
#from flask import Api, Resource, reqparse
import hashlib
import uuid

app = Flask(__name__)
app.config["DEBUG"] = False


myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["datas"]
mycol = mydb["data"]

mydbuser = myclient['users']
mycoluser = mydbuser['user']


# order of arrays [healthcare, food, transportation, housing, education]
total_array = [0, 0, 0, 0, 0]
max_array = [0, 0, 0, 0, 0]
min_array = [0, 0, 0, 0, 0]
average_array = [0, 0, 0, 0, 0]
user_array = [0, 0, 0, 0, 0]
perc_array = [0.0, 0.0, 0.0, 0.0, 0.0]

def null_arrays():
    global total_array
    global max_array
    global min_array
    global average_array
    global user_array
    global perc_array
    total_array = [0, 0, 0, 0, 0]
    max_array = [0, 0, 0, 0, 0]
    min_array = [999999, 999999, 999999, 999999, 999999]
    average_array = [0, 0, 0, 0, 0]
    user_array = [0, 0, 0, 0, 0]
    perc_array = [0.0, 0.0, 0.0, 0.0, 0.0]


def add_datas_from_csv(csvname):
    header = ["Sector", "Expense", "CustomerName"]
    csvfile = open(csvname, 'r')
    reader = csv.DictReader(csvfile)
    for each in reader:
        row = {}
        for field in header:
            row[field] = each[field]
        print(row)
        mycol.insert_one(row)




@app.route('/getaverage', methods=['GET'])
def get_average(sector, username):
    global average_array
    global total_array
    myquery = {"Sector": str(sector), "CustomerName": str(username)}
    count = 0
    average = 0.0
    for i in mycol.find(myquery):
        count += 1
    match str(sector):
        case "Healtcare":
            average = float(total_array[0]/count)
            average_array[0] = average
        case "Food":
            average = float(total_array[1] / count)
            average_array[1] = average
        case "Transportation":
            average = float(total_array[2] / count)
            average_array[2] = average
        case "Housing":
            average = float(total_array[3] / count)
            average_array[3] = average
        case "Education":
            average = float(total_array[4] / count)
            average_array[4] = average
        case default:
            print("error")
    return str(average)

@app.route('/getuserexpenses', methods=['GET'])
def user_expenses():
    global total_array
    global max_array
    global min_array
    global average_array
    username = request.args.get("username")
    myquery = {"CustomerName": str(username)}
    null_arrays()
    count = 0
    for i in mycol.find(myquery):
        count += 1
        match i.get("Sector"):
            case "Healtcare":
                if int(i.get("Expense")) > max_array[0]:
                    max_array[0] = int(i.get("Expense"))
                if int(i.get("Expense")) < min_array[0]:
                    min_array[0] = int(i.get("Expense"))
                total_array[0] += int(i.get("Expense"))
            case "Food":
                if int(i.get("Expense")) > max_array[1]:
                    max_array[1] = int(i.get("Expense"))
                if int(i.get("Expense")) < min_array[1]:
                    min_array[1] = int(i.get("Expense"))
                total_array[1] += int(i.get("Expense"))
            case "Transportation":
                if int(i.get("Expense")) > max_array[2]:
                    max_array[2] = int(i.get("Expense"))
                if int(i.get("Expense")) < min_array[2]:
                    min_array[2] = int(i.get("Expense"))
                total_array[2] += int(i.get("Expense"))
            case "Housing":
                if int(i.get("Expense")) > max_array[3]:
                    max_array[3] = int(i.get("Expense"))
                if int(i.get("Expense")) < min_array[3]:
                    min_array[3] = int(i.get("Expense"))
                total_array[3] += int(i.get("Expense"))
            case "Education":
                if int(i.get("Expense")) > max_array[4]:
                    max_array[4] = int(i.get("Expense"))
                if int(i.get("Expense")) < min_array[4]:
                    min_array[4] = int(i.get("Expense"))
                total_array[4] += int(i.get("Expense"))
            case default:
                print("error")
    get_average("Healtcare", username)
    get_average("Food", username)
    get_average("Transportation", username)
    get_average("Housing", username)
    get_average("Education", username)
    print("total", total_array)
    print("average", average_array)
    return "{\"status\":\"success\", \"max\":"+str(max_array)+" , \"min\":"+str(min_array)+" , \"average\":" +str(average_array)+"}"

@app.route('/getexpenses', methods=['GET'])
def total_expenses():
    global total_array
    null_arrays()
    count = 0
    for i in mycol.find():
        count += 1
        match i.get("Sector"):
            case "Healtcare":
                total_array[0] += int(i.get("Expense"))
            case "Food":
                total_array[1] += int(i.get("Expense"))
            case "Transportation":
                total_array[2] += int(i.get("Expense"))
            case "Housing":
                total_array[3] += int(i.get("Expense"))
            case "Education":
                total_array[4] += int(i.get("Expense"))
            case default:
                print("error")
    return total_array

@app.route('/getsector', methods=['GET'])
def sector_expenses():
    global total_array
    global max_array
    global min_array
    global average_array
    total_expenses()
    user_expenses()
    get_average()
    sector = request.args.get("sector")
    index = 0
    match str(sector):
        case "Healtcare":
            index = 0
        case "Food":
            index = 1
        case "Transportation":
            index = 2
        case "Housing":
            index = 3
        case "Education":
            index = 4
    return "{\"max\":" +str(max_array[index])+ ",\"min\": "+str(min_array[index])+ ",\"average\": "+str(average_array[index]) +"}"


@app.route('/getpercexpenses', methods=['GET'])
def total_user_expense():
    global user_array
    global total_array
    global perc_array
    total_expenses()
    username = request.args.get("customer_name")
    mydict = {"CustomerName": username}
    for i in mycol.find(mydict):
        match i.get("Sector"):
            case "Healtcare":
                user_array[0] += int(i.get("Expense"))
            case "Food":
                user_array[1] += int(i.get("Expense"))
            case "Transportation":
                user_array[2] += int(i.get("Expense"))
            case "Housing":
                user_array[3] += int(i.get("Expense"))
            case "Education":
                user_array[4] += int(i.get("Expense"))
            case default:
                print("error")
    for i in range(len(user_array)):
        perc_array[i] = round((float(user_array[i]/total_array[i])*100), 2)
    json_data = dumps(list(perc_array))
    return json_data


@app.route('/getdata', methods=['GET'])
def get():
    try:
        token = request.args.get("token")
        sector = request.args.get("sector")
        myquery = {
            'token': str(token)
        }
        count = mycoluser.count_documents(myquery)
        if count == 1:
            json_data = dumps(list(mycol.find({'Sector': sector})))
            return json_data
    except:
        return "{\"status\":\"fail\"}"


if __name__ == '__main__':
    #add_datas_from_csv("Dataset.csv") # Run only one time at begining!
    app.run(port=5001)